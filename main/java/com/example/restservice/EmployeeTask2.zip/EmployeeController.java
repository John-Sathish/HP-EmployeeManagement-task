package com.example.restservice;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class EmployeeController {
	
	
	Employees employeesList = new Employees();;
	
	@GetMapping(path = "/employees", produces = "application/json")
	public Employees getEmployees() {
		return EmployeeManager.employees;
	}
	
	@PostMapping(path = "/employees")
	public String addEmployee(@RequestBody Employee employee) {
		employeesList.get_employee().add(employee);
		return "Employee of ID:" + employee.getEmployee_id() + " added successfully!";
		
	}
	
	
	
	

}
